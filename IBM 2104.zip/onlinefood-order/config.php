<?php

$conn = mysqli_connect('localhost','root','','onlinefoodorder') or die('connection failed');

?>