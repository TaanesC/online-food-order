-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2022 at 04:48 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onlinefoodorder`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`id`, `title`, `image_name`, `featured`, `active`) VALUES
(4, 'Fast Food', 'Food_Category_309.png', 'Yes', 'Yes'),
(5, 'Chinese Food', 'Food_Category_353.png', 'Yes', 'Yes'),
(9, 'Malay food', 'Food_Category_506.png', 'Yes', 'Yes'),
(10, 'Indian Food', 'Food_Category_919.png', 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_food`
--

CREATE TABLE `tbl_food` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image_name` varchar(255) NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `featured` varchar(10) NOT NULL,
  `active` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_food`
--

INSERT INTO `tbl_food` (`id`, `title`, `description`, `price`, `image_name`, `category_id`, `featured`, `active`) VALUES
(13, 'Chicky Crisp Combo', '\n\n', '20.00', 'Food-Name-893.jpg', 4, 'Yes', 'Yes'),
(14, 'Dinner Plate', '', '15.00', 'Food-Name-1447.jpg', 4, 'Yes', 'Yes'),
(15, 'Cheezy Wedges', '', '7.00', 'Food-Name-6805.jpg', 4, 'Yes', 'Yes'),
(16, 'Aloha Chicken', '', '6.00', 'Food-Name-5240.jpeg', 4, 'Yes', 'Yes'),
(17, 'Chicken Pepperoni', '', '6.00', 'Food-Name-1909.jpeg', 4, 'Yes', 'Yes'),
(18, 'Kuey Teow Goreng', '', '5.00', 'Food-Name-5316.jpg', 5, 'Yes', 'Yes'),
(19, 'Hokkien Mee', '', '6.00', 'Food-Name-8313.jpg', 5, 'Yes', 'Yes'),
(20, 'Wan Tan Mee', '', '5.00', 'Food-Name-5538.jpg', 5, 'Yes', 'Yes'),
(21, 'Nasi Ayam', '', '4.00', 'Food-Name-4741.webp', 5, 'Yes', 'Yes'),
(22, 'Nasi Lemak', '', '2.00', 'Food-Name-6037.jpg', 9, 'Yes', 'Yes'),
(23, 'Dim Sum', '', '13.00', 'Food-Name-1950.avif', 5, 'Yes', 'Yes'),
(24, 'Satay', '', '10.00', 'Food-Name-3103.webp', 9, 'Yes', 'Yes'),
(25, 'Mee Goreng', '', '5.00', 'Food-Name-2749.crdownload', 9, 'Yes', 'Yes'),
(26, 'Nasi Goreng', '', '6.00', 'Food-Name-1060.jpg', 9, 'Yes', 'Yes'),
(27, 'Chendol', '', '3.00', 'Food-Name-2098.jpg', 9, 'Yes', 'Yes'),
(28, 'Samosa', '', '4.00', 'Food-Name-6157.jpg', 10, 'Yes', 'Yes'),
(29, 'Roti Canai', '', '3.00', 'Food-Name-743.jpg', 10, 'Yes', 'Yes'),
(30, 'Tosai', '', '3.00', 'Food-Name-2863.webp', 10, 'Yes', 'Yes'),
(31, 'Poori', '', '3.00', 'Food-Name-7934.jpg', 10, 'Yes', 'Yes'),
(32, 'Biriyani', '', '15.00', 'Food-Name-4619.jpg', 10, 'Yes', 'Yes');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `id` int(10) UNSIGNED NOT NULL,
  `food` varchar(150) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `qty` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `order_date` datetime NOT NULL,
  `status` varchar(50) NOT NULL,
  `customer_name` varchar(150) NOT NULL,
  `customer_contact` varchar(20) NOT NULL,
  `customer_email` varchar(150) NOT NULL,
  `customer_address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`id`, `food`, `price`, `qty`, `total`, `order_date`, `status`, `customer_name`, `customer_contact`, `customer_email`, `customer_address`) VALUES
(19, 'Chicky Crisp Combo', '20.00', 1, '20.00', '2022-07-12 00:00:00', 'Ordered', 'Taanes', '522456215621', 'thinesh7511@gmail.com', 'w4ecrtvybuniom'),
(20, 'Chicken Pepperoni', '6.00', 1, '6.00', '2022-07-13 00:00:00', 'Ordered', 'vijay', '123456', 'vijay@gmail.com', 'exrctvygbuhni8520'),
(21, 'Chicky Crisp Combo', '20.00', 1, '20.00', '2022-07-13 00:00:00', 'Ordered', 'taanes', '343494949555555', 'vijay@gmail.com', 'etyuiopdfghjkl874520'),
(22, 'Chicky Crisp Combo', '20.00', 1, '20.00', '2022-07-17 00:00:00', 'Ordered', 'taanes', '0123456789', 'taanes.C@gmail.com', 'no 678, jalan 56, taman penang, sungai petani');

-- --------------------------------------------------------

--
-- Table structure for table `user_form`
--

CREATE TABLE `user_form` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_form`
--

INSERT INTO `user_form` (`id`, `name`, `email`, `password`, `image`) VALUES
(1, 'Taanes', 'taanes.C@gmail.com', '9dea2ad6a9bc0f4fd2ecc0445e0f5277', 'DSC00350.JPG'),
(2, 'Thinesh', 'thinesh7511@gmail.com', '4cf4b59aa4ce4f6b00bb6f55091e1a36', ''),
(3, 'Chaanthini', 'chaanthini@gmail.com', '4dea97bcaaa2c209658e83201e4d0d23', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_category`
--
ALTER TABLE `tbl_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_food`
--
ALTER TABLE `tbl_food`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_order`
--
ALTER TABLE `tbl_order`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_form`
--
ALTER TABLE `user_form`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_category`
--
ALTER TABLE `tbl_category`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_food`
--
ALTER TABLE `tbl_food`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `tbl_order`
--
ALTER TABLE `tbl_order`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `user_form`
--
ALTER TABLE `user_form`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
