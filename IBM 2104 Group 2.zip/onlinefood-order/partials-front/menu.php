<?php include('config/constants.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>V Food</title>

    <link rel="stylesheet" href="cs/style.css">
</head>

<body>
   

         <div class="navbar">
		 <style>
		 .navbar {
			 
			 overflow: hidden;
			 background-color: #333;
			 position: sticky; 
			 position: -webkit-sticky;
			 top: 0;
			 font-family: Ariel;
		 }
		 
		 .navbar a { 
		 float:left; 
		 display: block;
		 color: #ff0066;
		 text-align: center;
		 padding: 20px 40px;
		 text-decoration: none;
		 }
		 .navbar a.right {
			 float:right;
		 }
		 .navbar a:hover { 
		 background-color: #ddd;
		 color: #00cc66;
		 }
		 .navbar a.active { 
		 background-color: #666;
		 color: #ccff33;
		 }
		 </style>
		 
		 <a href="index.php"> Home</a>
		 		 <a  href="categories.php">Categories</a>
				 		 		 <a  href="foods.php">Order</a>
								                         <a href="home.php">User</a>



		 
		 
		 </div>
		 
		 <div class="about-section">
		 <h1>V FOOD</h1>
		 <h3>Online food Order</h3>
		 </div>
	</body>
	</html>
		  
            
