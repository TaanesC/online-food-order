	<section class="footer">
        <div class="container text-center">
            <p>All rights reserved. Designed By Taanes, Thinesh And Leow</p>
        </div>
    </section>
  
</body>
</html>